package com.app.tourguide.enums;

//trip type
public enum Category1Type {
    FAMILY, YOUTH, ROMANTIC
}

