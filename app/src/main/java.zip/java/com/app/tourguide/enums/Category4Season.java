package com.app.tourguide.enums;

//season
public enum Category4Season {
    SPRING, SUMMER, AUTUMN, WINTER
}
