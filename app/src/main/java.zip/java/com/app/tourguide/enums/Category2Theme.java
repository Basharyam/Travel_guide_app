package com.app.tourguide.enums;

//trip theme
public enum Category2Theme {
    CULTURAL, ADVENTURE, NATURE, NATVENTURE, NATCULTURE
}
