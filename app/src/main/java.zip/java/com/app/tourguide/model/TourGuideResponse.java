package com.app.tourguide.model;

import java.util.List;

public class TourGuideResponse {
    private List<Tour> tours;

    public List<Tour> getTours() {
        return tours;
    }
}

