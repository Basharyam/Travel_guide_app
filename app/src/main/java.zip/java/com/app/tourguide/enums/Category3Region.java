package com.app.tourguide.enums;

//region
public enum Category3Region {
    ASIA, EUROPE, AFRICA, NORTHAMERICA, SOUTHAMERICA
}
