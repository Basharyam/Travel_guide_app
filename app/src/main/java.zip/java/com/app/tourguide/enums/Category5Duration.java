package com.app.tourguide.enums;


public enum Category5Duration {
    THREEDAYS, FIVEDAYS, SEVENDAYS
}
